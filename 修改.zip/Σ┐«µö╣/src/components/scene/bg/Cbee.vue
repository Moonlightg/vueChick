<template>
  <div class="bee-box" title="蜜蜂鲜花">
    <div class="soil two"></div>
    <div class="soil"></div>
    <div class="flowerpot">
      <div class="flowerpot-top"></div>
      <div class="flowerpot-bottom"></div>
    </div>
    <div class="flower">
      <div class="flower-top">
        <p></p>
        <p></p>
        <p></p>
        <p></p>
      </div>
      <div class="flower-head"></div>
    </div>
    <div class="bee">
      <div class="bee-body"></div>
    </div>
    <div class="bee bee-2">
      <div class="bee-body"></div>
    </div>
    <div class="triangle-box two">
      <div class="item"></div>
      <div class="item"></div>
      <div class="item"></div>
    </div>
  </div>
</template>

<script>

export default {
  name: 'Bee',
  data() {
    return {
    }
  },
  components: {
  },
  methods: {
  }
}

</script>
