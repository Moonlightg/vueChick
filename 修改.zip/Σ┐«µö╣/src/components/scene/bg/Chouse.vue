<template>
  <div class="house" title="房子">
    <div class="house-1"></div>
    <div class="house-2-1"></div>
    <div class="house-2-2"></div>
    <div class="house-2"></div>
    <div class="house-3-1"></div>
    <div class="house-3-2"></div>
    <div class="house-3"></div>
    <div class="house-4"></div>
    <div class="house-5"></div>
    <div class="house-6"></div>
    <div class="house-7"></div>
    <div class="house-8"></div>
    <div class="house-9"></div>
  </div>
</template>

<script>

export default {
  name: 'Peak',
  data() {
    return {
    }
  },
  components: {
  },
  methods: {
  }
}

</script>
