<template>
  <div class="clouds" title="白云">
    <div class="cloud x1"></div>
    <div class="cloud x2"></div>
    <div class="cloud x3"></div>
  </div>
</template>

<script>

export default {
  name: 'Clouds',
  data() {
    return {
    }
  },
  components: {
  },
  methods: {
  }
}

</script>
