<template>
  <div class="peak-box" title="山峰风车">
    <div class="peak-1"></div>
    <div class="peak-2"></div>
    <div class="peak-3"></div>
    <div class="peak-4"></div>
    <div class="peak-5"></div>
    <div class="peak-6"></div>
    <div class="peak-7">
      <div class="peak-7-1"></div>
      <div class="peak-7-2"></div>
    </div>
    <div class="peak-8"></div>
    <div class="peak-9"></div>
    <div class="windmill">
      <div class="windmill-1"></div>
      <div class="windmill-2"></div>
      <div class="windmill-3"></div>
      <div class="windmill-4"></div>
      <div class="windmill-5">
        <div class="windmill-5-1"></div>
        <div class="windmill-5-2"></div>
      </div>
    </div>
  </div>
</template>

<script>

export default {
  name: 'Peak',
  data() {
    return {
    }
  },
  components: {
  },
  methods: {
  }
}

</script>
