<template>
  <div class="fence" title="护栏">
    <span></span>
    <span></span>
    <span></span>
    <span></span>
  </div>
</template>

<script>

export default {
  name: 'Fence',
  data() {
    return {
    }
  },
  components: {
  },
  methods: {
  }
}

</script>
