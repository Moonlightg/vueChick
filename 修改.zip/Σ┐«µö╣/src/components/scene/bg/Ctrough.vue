<template>
  <div class="trough" title="鸡饭碗">
    <span></span>
    <span></span>
    <div class="fodder"></div>
    <div class="trough-l">
      <p></p>
      <p></p>
      <p></p>
    </div>
  </div>
</template>

<script>

export default {
  name: 'Trough',
  data() {
    return {
    }
  },
  components: {
  },
  methods: {
  }
}

</script>
