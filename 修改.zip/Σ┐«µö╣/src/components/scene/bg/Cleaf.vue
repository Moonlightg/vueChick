<template>
  <div class="leaf-box" title="叶子">
    <div class="leaf-item leaf-1"></div>
    <div class="leaf-item leaf-2"></div>
    <div class="leaf-item leaf-3"></div>
    <div class="leaf-item leaf-4"></div>
  </div>
</template>

<script>

export default {
  name: 'Leaf',
  data() {
    return {
    }
  },
  components: {
  },
  methods: {
  }
}

</script>
