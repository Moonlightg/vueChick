<template>
  <div class="grass-1" title="草">
    <span></span>
    <span></span>
    <span></span>
    <span></span>
    <span></span>
    <span></span>
    <div class="triangle-box">
      <div class="item"></div> 
      <div class="item"></div> 
      <div class="item"></div> 
      <div class="item"></div>
    </div>
  </div>
</template>

<script>

export default {
  name: 'Grass',
  data() {
    return {
    }
  },
  components: {
  },
  methods: {
  }
}

</script>
