<template>
  <div class="sunlight" title="太阳光">
    <span></span>
    <span></span>
    <span></span>
    <span></span>
  </div>
</template>

<script>

export default {
  name: 'Sunlight',
  data() {
    return {
    }
  },
  components: {
  },
  methods: {
  }
}

</script>
