<template>
  <div class="penguin penguin-happy">
    <div class="pen-body">
      <div class="pen-eye"></div>
      <div class="pen-blusher"></div>
      <div class="pen-mouth"></div>
      <div class="pen-mouth2"></div>
      <div class="food">
        <p></p>
        <div class="dot-box">
          <span></span>
          <span></span>
        </div>
      </div>
      <div class="pen-wing"></div>
    </div>
  </div>
</template>

<script>

export default {
  name: 'PenguinDefault',
  data() {
    return {
    }
  },
  components: {
  },
  methods: {
  }
}

</script>
