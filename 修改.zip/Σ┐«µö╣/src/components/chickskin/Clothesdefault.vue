<template>
  <div></div>
</template>

<script>

export default {
  name: 'Clothesdefault',
  data() {
    return {
    }
  },
  components: {
  },
  methods: {
  }
}

</script>
