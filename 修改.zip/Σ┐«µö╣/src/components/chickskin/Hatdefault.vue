<template>
  <div></div>
</template>

<script>

export default {
  name: 'Hatdefault',
  data() {
    return {
    }
  },
  components: {
  },
  methods: {
  }
}

</script>
