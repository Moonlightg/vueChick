<template>
  <div class="hat-painter">
    <span></span>
  </div>
</template>

<script>

export default {
  name: 'hatPainter',
  data() {
    return {
    }
  },
  components: {
  },
  methods: {
  }
}

</script>
