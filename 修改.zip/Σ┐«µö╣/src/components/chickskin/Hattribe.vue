<template>
  <div class="hat-tribe">
    <span></span>
    <span></span>
    <span></span>
    <span></span>   
  </div>
</template>

<script>

export default {
  name: 'hatTribe',
  data() {
    return {
    }
  },
  components: {
  },
  methods: {
  }
}

</script>
