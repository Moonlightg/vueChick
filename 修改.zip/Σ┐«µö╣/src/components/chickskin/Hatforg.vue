<template>
  <div class="hat-frog">
    <span class="hat-frog-eye el"></span>
    <span class="hat-frog-eye er"></span>
    <span class="sun-cured"></span>
  </div>
</template>

<script>

export default {
  name: 'hatForg',
  data() {
    return {
    }
  },
  components: {
  },
  methods: {
  }
}

</script>
