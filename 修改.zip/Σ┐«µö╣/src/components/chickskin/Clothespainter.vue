<template>
  <div class="clothes-tribe">
    <div class="ct-box">
      <span></span>
    </div> 
  </div>
</template>

<script>

export default {
  name: 'Clothestribe',
  data() {
    return {
    }
  },
  components: {
  },
  methods: {
  }
}

</script>
