<template>
  <div class="jacket-skin"> 
    <div class="jacket-frog">
      <span></span>
      <span></span>
      <span></span>
      <span></span>
      <span></span>
    </div>
  </div>
</template>

<script>

export default {
  name: 'clothesForg',
  data() {
    return {
    }
  },
  components: {
  },
  methods: {
  }
}

</script>
