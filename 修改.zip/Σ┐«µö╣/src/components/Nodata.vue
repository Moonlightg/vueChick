<template>
  <div class="no-data">
    <i class="el-icon-hot-water"></i>
    <p>暂无数据</p>
  </div>
</template>

<script>

export default {
  name: 'Nodata',
  data() {
    return {
    }
  },
  components: {
  },
  methods: {
  }
}

</script>
